const express = require('express');
const router = express.Router();
const tripsController = require('../../app_api/databases/controllers/trips'); // Adjusted the relative path

/* GET home page. */
router.get('/', tripsController.tripList);

module.exports = router;
