const express = require('express');
const router = express.Router();
const trips = require('../controllers/trips')

// Route to get a list of all trips
router
    .route('/trips')
    .get(trips.tripList);

// Route to find and return a single trip by trip code
router
    .route('/trips/:tripCode')
    .get(trips.tripsFindCode);

module.exports = router;